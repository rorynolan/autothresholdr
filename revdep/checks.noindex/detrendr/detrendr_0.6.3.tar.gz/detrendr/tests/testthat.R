library(testthat)
library(detrendr)

test_check("detrendr")
